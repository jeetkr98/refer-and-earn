# 🪙 Refer & Earn – Free Demat Account Links

## 💡 About
This is a **Refer & Earn website** that promotes free **Demat account opening links** from India’s top brokers:
- 🟢 **Angel One**
- 🔵 **Upstox**
- 🟣 **Jainam JPlus**

Visitors can open accounts using your referral links and both of you earn rewards.

## 🌐 Live Website
Once you publish via GitHub Pages, your live site will appear here:
👉 **https://YOUR_USERNAME.github.io/refer-and-earn/**

*(Replace `YOUR_USERNAME` with your GitHub username)*

## ⚙️ Features
✅ Simple & clean HTML design  
✅ Fully mobile responsive  
✅ SEO-ready (`robots.txt` + `sitemap.xml`)  
✅ 100% Free Hosting via **GitHub Pages**  
✅ Easy to edit referral links anytime  

## 🧭 Setup Instructions
1. **Fork or Download** this repository  
2. Upload the files (`index.html`, `robots.txt`, `sitemap.xml`, `README.md`)  
3. Go to **Settings → Pages**  
4. Select `main` branch and `/ (root)` folder  
5. Click **Save** → Your website goes live in a few seconds 🚀  

## ✍️ Author
👤 **Jeet Kumar**  
📧 Contact for collaboration or partnership opportunities.

## 📜 License
This project is open-source under the **MIT License**.  
You are free to use, modify, and share it.
